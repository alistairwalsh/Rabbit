# -*- coding: utf-8 -*-

"""
BITalino Python API

__init__

Created on Nov 27 11:25:00 2013

@author: Carlos Carreiras

"""

# version
from _version import __version__

# make class available
from bitalino import BITalino
